# 饱和火力
这里是饱和火力模组官方Git存储位置
Here is the official Git storage location of the [Saturation-Firepower] module for Mindustry!
# SF有什么—What we have？
200+新方块，囊括各方各面！更多工厂、钻头、传输组件、防御设施、单位工厂！
200+ new bolcks,embracing all sides!
50+形态各异的功能不同的炮塔，火力全开！
50+ Turrets with different functions in different shapes, fire as you way!
40+新单位，以及对原版单位的全面升级！船新的游戏体验！
40+ New units, as well as a complete upgrade of the original units! A new gaming experience!
18张新战役地图（部分在建，最终将有30左右），更壮阔的战斗场景！更高难度的战斗！更强大的敌人！
18 new campaign map (some under construction, eventually around 30), more spectacular battle scenarios! More difficult battles! Stronger enemies!
尽可能真实的战场环境与多样的战术选择。从教程开始到困难的主线战役，以及为挑战者准备的高难支线战役。
# 模组QQ群：181108928
点击链接加入群聊【[mindustry]饱和火力】：https://jq.qq.com/?_wv=1027&k=lzXXr2ED

# 服务器/Sever:
mdtbaohe.work:1324
